#include "REG51.h"

void Delay(unsigned int xms){
	unsigned char i, j;
	while (xms--){
		i = 2;
		j = 239;
		do{
			while(--j);
		}while(--i);
	}	
}
void main(void){
	unsigned char i;
	while(1){
		for(i=0;i<8;i++){
			P2 = ~(0x01 << i);
			Delay(100);
		}
	}
}