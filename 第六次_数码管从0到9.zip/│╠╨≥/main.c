#include "REG51.h"

/*
				 P20
			 	 ___
		 P25|   |P21
				|___|
	 	 P24|P26|P22
				|___| . P27
				 P23
*/

void Delay(unsigned int xms){
	unsigned char i,j;
	while(xms--){
		i = 2;
		j = 239;
		do{
			while(--j);
		}while(--i);
	}
}

int main(){
	while(1){
		P2 = 0xC0;//0
		Delay(1000);
		P2 = 0xF9;//1
		Delay(1000);
		P2 = 0xA4;//2
		Delay(1000);
		P2 = 0xB0;//3
		Delay(1000);
		P2 = 0x99;//4
		Delay(1000);
		P2 = 0x92;//5
		Delay(1000);
		P2 = 0x82;//6
		Delay(1000);
		P2 = 0xF8;//7
		Delay(1000);
		P2 = 0x80;//8
		Delay(1000);
		P2 = 0x90;//9
		Delay(1000);
	}
}