#include "REG51.h"
sbit P1_0 = 0x90;
sbit P2_0 = 0xA0;

void Delay(unsigned int xms){
	unsigned char i, j;
	while(xms--){
		i = 2;
		j = 239;
		do{
			while (--j);
		}while(--i);
	}
}
void main(void){
	while(1){
		if(P1_0==0){
			Delay(20);
			while(P1_0==0);
			Delay(20);
			
			P2_0 = ~P2_0;
		}
	}
}