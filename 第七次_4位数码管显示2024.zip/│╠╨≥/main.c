#include "REG51.h"

void Delay(unsigned int xms){
	unsigned char i,j;
	while(xms--){
		i = 2;
		j = 239;
		do{
			while(--j);
		}while(--i);
	}
}

int main(){
	while(1){
		P3 = 0x01;//��һλ
		P2 = 0xA4;//2
		Delay(1);
		P3 = 0x02;//�ڶ�λ
		P2 = 0xC0;//0
		Delay(1);
		P3 = 0x04;//����λ
		P2 = 0xA4;//2
		Delay(1);
		P3 = 0x08;//����λ
		P2 = 0x99;//4
		Delay(1);
	}
}